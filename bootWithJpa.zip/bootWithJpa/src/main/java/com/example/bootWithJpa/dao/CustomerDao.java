package com.example.bootWithJpa.dao;

import java.util.List;

import com.example.bootWithJpa.entity.Customer;


public interface CustomerDao {

	List<Customer> getCustomerList();

	void saveCustomer(Customer customer);
	
}
