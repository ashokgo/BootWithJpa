package com.example.bootWithJpa.daoImpl;

import java.util.Collections;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.bootWithJpa.dao.CustomerDao;
import com.example.bootWithJpa.entity.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	
	@Autowired
    private SessionFactory sessionFactory;
	
	@Override
	public List<Customer> getCustomerList() {
		List<Customer> customerList = Collections.emptyList();
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<Customer> cquery = cb.createQuery(Customer.class);
		Root<Customer> root = cquery.from(Customer.class);
		try {
			cquery.select(root);
			
			customerList = session.createQuery(cquery).getResultList();
		} catch (Exception e) {
			System.out.println(e);
		}
		return customerList;
	}

	@Override
	public void saveCustomer(Customer customer) {
		Session session = sessionFactory.getCurrentSession();
		session.save(customer);
	}

}
