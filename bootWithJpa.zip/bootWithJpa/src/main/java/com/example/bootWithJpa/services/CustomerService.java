package com.example.bootWithJpa.services;

import java.util.List;

import com.example.bootWithJpa.entity.Customer;

public interface CustomerService {
	
	public List<Customer> getCustomerList();

	public String saveCustomer(Customer customerDto);
}
