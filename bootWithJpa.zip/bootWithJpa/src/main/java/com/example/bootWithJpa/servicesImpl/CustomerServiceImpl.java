package com.example.bootWithJpa.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.bootWithJpa.dao.CustomerDao;
import com.example.bootWithJpa.entity.Customer;
import com.example.bootWithJpa.services.CustomerService;

@Transactional
@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerDao customerDao;
	
	@Override
	public List<Customer> getCustomerList() {
		return customerDao.getCustomerList();
	}

	@Override
	public String saveCustomer(Customer customer) {
		customerDao.saveCustomer(customer);
		return "success";
	}

}
