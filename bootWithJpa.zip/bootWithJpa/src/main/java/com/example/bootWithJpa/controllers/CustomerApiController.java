package com.example.bootWithJpa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.bootWithJpa.entity.Customer;
import com.example.bootWithJpa.services.CustomerService;

@RestController
@RequestMapping("/api/")
public class CustomerApiController {
	
	@Autowired
	private CustomerService customerService;
	
	
	@GetMapping(value="getCustomerList")
	private List<Customer> getCustomerList() {
		return customerService.getCustomerList();
	}
	
	@PostMapping(value="saveCustomer")
	private String saveCustomer(@RequestBody Customer customer) {
		return customerService.saveCustomer(customer);
	}
}
